### pirate.warlords
<br>
<br>
This plugin adds 3 pirate person ships to the 3 pirate regions.<br>
<br>
The north, core and south pirates each get a pirate warlord person ship. Like other person ships, the average spawn time is like 10 minutes, and the chance of appearing if no other person ships exist for this region is 50%. All 3 ships are captureable Bactrians with mixed Human and Korath equipment, a Jump Drive, 5 Androids and some attribute improvements. <br>
<br>
North Pirate Warlord found in: Arneb, Alnilam, Almaaz <br>
Core Pirate Warlord found in: Alcyone, Misam, Almach, Algenib, Gienah <br>
South Pirate Warlord found in: Shaula, Antares, Nunki, Men, Alpherg, Citadelle, Belenos <br>
<br>
<br>
Changelog:<br>
<br>
2024-02-15<br>
initial release<br>

