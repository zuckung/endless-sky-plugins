### coalition.shopping
<br>
<br>
Adds all Coalition/Heliarch/Lunarium outfits and ships to 'Far Home' in 'Homeward' system.<br>
<br>
Adds all existing coalition outfitters and shipyards to 'Far Home'. Also adds a new shipyard and a new outfitter.<br>
The shipyard sells all missing Heliarch ships.<br>
The outfitter sells all missing Heliarch Outfits and Coalition/Heliarch license.<br>
<br>
<br>
Changelog:<br>
<br>
2023-10-17<br>
added plugin.txt<br>
<br>
2023-10-05<br>
initial release<br>

