### automata.destruction.0percent
<br>
<br>
Modifies the self destruction chance of Sestor and Mereti ships to a value of 0.0 (0%).<br>
<br>
Sestor 349/109/78/71/53/40/27 and Mereti 512/256/128/64/32/16/8 ships have a self destruction value of 0.0 (0%) now.<br>
You can easily change the values in automata.txt for each ship ('"self destruct" .0') to a value of your choice. I.e. 0.12 is 23%, 0.3 is 51%, 0.5 is 75%. Its calculated twice, first the chance for self destruction on boarding(i.e. 0.3) is 30%, then of the remaining 70% again 30% chance for self destruction on capturing. That makes 30% + 21% = 51% overall chance for self destruction on a capturing try.<br>
<br>
<br>
Changelog:<br>
<br>
2023-10-17<br>
added plugin.txt<br>
<br>
2023-09-07<br>
changed icon<br>
changed about.txt<br>
changed readme<br>








