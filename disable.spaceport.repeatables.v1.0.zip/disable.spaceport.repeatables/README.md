### disable.spaceport.repeatables
<br>
<br>
Disables all spaceport repeatable missions. These missions annoy me. Removes the 8 dialog repeatables and the 8 defend planet missions.<br>
<br>
<br>
<ul>
<li> "Shady passenger transport 1" </li>
<li> "Shady passenger transport 2" </li>
<li> "Shady passenger transport 3" </li>
<li> "Drug Running 1" </li>
<li> "Drug Running 2" </li>
<li> "Drug Running 3" </li>
<li> "Courier 1" </li>
<li> "Courier 2" </li>
<li> "Southern Pirate Attack" </li>
<li> "Northern Pirate Attack" </li>
<li> "Core Pirate Attack" </li>
<li> "Pirate Occupation [0]" </li>
<li> "Pirate Occupation [1]" </li>
<li> "Pirate Occupation [2]" </li>
<li> "Raider Attack 1" </li>
<li> "Raider Attack 2" </li>
</ul>
<br>
<br>
Changelog:<br>
<br>
2023-10-17<br>
added plugin.txt<br>
<br>
2023-09-03<br>
added the 2 syndicate alien attack missions<br>
<br>
2023-08-31<br>
added the 3 pirate occupation missions<br>
added icon.png<br>