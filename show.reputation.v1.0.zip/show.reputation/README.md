### show.reputation
<br>
<br>
Enables a job on every planet's job board, that shows the reputation values.<br>
<br>
Accept the job, start, land again, and the reputations conversation pops up. Then you can choose between viewing the 35 most useful or all.<br>
<br>
<br>
<img src='https://raw.githubusercontent.com/zuckung/endless-sky-plugins/master/myplugins/show.reputation/screenshot.jpg' width='100'>
<br>
<a href='https://github.com/zuckung/endless-sky-plugins/tree/main/tools/show_reputation_plugin_script'>python script</a> to generate the plugin<br>
<br>
<br>
Changelog:<br>
<br>
2024-03-16<br>
added option to show all rep values or just the 35 most useful<br>
changed to better reputation handling (thx to zoura for the tip)<br>
<br>
2024-03-14<br>
initial release<br>

