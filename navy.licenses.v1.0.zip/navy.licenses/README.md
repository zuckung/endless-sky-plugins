### navy.licenses
<br>
<br>
Adds a mission on Stormhold(Alcyone system) which leads you to Geminus(Castor system) to buy the four Navy licenses.<br>
<br>
The mission can get started with 2,5 million credits cash available. You have to pay 50.000 credits for the contact and 2 million for the four licenses.<br>
If you reject the mission, you can restart it on other visits.<br>
You get the following licenses : Navy license, Navy Auxiliary license, Navy Cruiser license, Navy Carrier license.<br>
<br>
<br>
Changelog:<br>
<br>
2024-02-17<br>
initial release<br>

