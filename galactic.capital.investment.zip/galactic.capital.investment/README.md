### galactic capital investment <br>
(story, repeatable mission)(made for 0.10.0) <br>
<br>
Implements a two mission chain that enables regular spaceport investment opportunities which result in small daily income. Available in human, quarg and hai space with 2 million credits cash. <br>
(inspired by a-alhusaini's investment bank plugin) <br>