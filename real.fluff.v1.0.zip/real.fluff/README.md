### real.fluff
<br>
<br>
A bunch of side missions which reward unique pets. <br>
<br>
Lore-friendly, total useless, but cute pet outfits, with storylines. All missions have a 20% chance of appearing, except alien mission which has 100%.<br>
<ul>
<li>Alien - land somewhere in human space, hidden destination is Danoa system</li>
<li>Cat - mission found on Deadman's Cove (Almach)</li>
<li>Ferret - mission found on Bivrost (Markeb)</li>
<li>Hamster - mission found on Twinstar (Alniyat)</li>
<li>Koala - mission found on New Portland (Delta Sagittarii)</li>
<li>Ocelot - mission found on Farpoint (Alnitak) needs 1000 combat xp</li>
<li>Rabbit - mission found on Starcross (Acrux)</li>
<li>Raccoon - mission found on Foundry (Achernar)</li>
<li>Squirrel - mission found on Heartvalley (Io Lowe, Hai space)</li>
</ul>
After collecting them all, you get a missions (20%) with unique rewards.<br>
<img src='https://raw.githubusercontent.com/zuckung/endless-sky-plugins/master/myplugins/real.fluff/screenshot.jpg' width='400'>
<br>
<br>
Changelog:<br>
<br>
2024-03-31<br>
new category pets<br>
gave puny an image and added to pets<br>
a new missions, after collecting all pets, with a unique reward<br>
converted scene pngs to jpg<br>
minor tweaks<br>
<br>
2024-03-15<br>
bugfixes<br>
added cat mission<br>
added 4 new scene images<br>
changed images to ai generated<br>
<br>
2023-10-17<br>
added plugin.txt<br>
<br>
2023-10-03<br>
added ocelot mission<br>
added raccoon mission<br>
added alien mission<br>
<br>
2023-09-23<br>
added ferret mission
added koala mission<br>
added rabbit mission<br>
added hamster mission<br>
<br>
2023-09-20<br>
added squirrel mission chain<br>
added 5 pet outfits with images<br>
initial release<br>