### too many asteroids <br>
(1-6 system attributes changed, in 540 systems)(made for 0.10.0) <br>
<br>
Removes all non-mineable asteroids from all systems. Mineable asteroids and asteroid belts are untouched. <br>