### disable.person.ships <br>
<br>
<br>
Disables all 14 random spawning person ships.<br>
<br>
<ul>
<li>	"Michael Zahniser" </li>
<li>	"Cap'n Pester" </li>
<li>	"Marauding Max" </li>
<li>	"Captain Nate" </li>
<li>	"Tranquility" </li>
<li>	"Power of the People" </li>
<li>	"Local God" </li>
<li>	"Subsidurial" </li>
<li>	"Prototype B3-CC4" </li>
<li>	"Rais Iris XVIII" </li>
<li>	"Zitchas" </li>
<li>	"Brick" </li>
<li>	"Gefullte Taubenbrust" </li>
<li>	"MasterOfGrey" </li>
<li>	"Patrol Team" </li>
</ul>
<br>
<br>
Changelog:<br>
<br>
2024-02-02<br>
added 0.10.5 "Patrol Team"<br>
<br>
2023-10-17<br>
added plugin.txt<br>
<br>
2013-08-31<br>
added icon.png<br>