### devil-run.unhidden
<br>
<br>
Removes the hidden tag from system Devil-Run. It can be found near the core and opens the path to the Deep Space systems and the Devil-Hide system via wormhole.<br>
<br>
Originally this system opens during hai reveal storyline, which is disabled because of a rework. Unfortunately some Remnant jobs rely on the Deep Space systems hidden behind a wormhole in Devil-Run. This plugin makes this system visible and reachable(by jump drive) in eastern syndicate.<br>
The Devil-Hide system is also a nice system to farm Marauder Leviathans.<br>
<br>
<br>
Changelog:<br>
<br>
2023-10-17<br>
added plugin.txt<br>
<br>
2023-08-31<br>
added icon.png<br>