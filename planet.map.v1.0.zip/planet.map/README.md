### planet.map
<br>
<br>
Planetary map travelling concept : start a new pilot, use 'start: planet.map' and follow the small story line. See the readme for details.<br>
<br>
This is just a proof of concept of an idea by Epsil-Astra.<br>
Basically a planet in a starsystem is a wormhole to a starsystem with changed background, to look like a ground map. The planets there look like cities. The galaxy background is a single whole planet. It simulates travelling on a planet you've landed on. Other starsystems act as different bioms, like forest, desert, sea.<br>
A small storyline got added.<br>
<br>
As in the spirit of Epsil-Astra, feel free to modify/use this plugin for your own content creation.<br> 
<br>
<img src='https://raw.githubusercontent.com/zuckung/endless-sky-plugins/master/myplugins/planet.map/screenshot.jpg' width='400'>
<img src='https://raw.githubusercontent.com/zuckung/endless-sky-plugins/master/myplugins/planet.map/screenshot1.jpg' width='400'>
<br>
<br>
Changelog:<br>
<br>
2024-03-26<br>
fixes and adjustments<br>
added galaxy planet<br>
added 4 new locations, with 2 new backgrounds<br>
<br>
2024-03-24<br>
initial release<br>