### no.more.mereti.mines
<br>
<br>
Removes the mines from Mereti ships and replaces them with Husk-Slice to increase game performance.<br>
<br>
Replaces Cluster Mine Layer, Cluster Mine Racks and Cluster Mines with Husk-Slice cannons, on Model 16/32/64/128/256/512. For every removed mine layer a cannon got added. That increases game performance in mass fights, like in Mesuket system.<br>
<br>
<br>
Changelog:<br>
<br>
2024-02-04<br>
initial release<br>

