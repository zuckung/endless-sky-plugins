### automata.in.human.space
<br>
<br>
Brings jump drive equipped automata into human space after the wanderer campaign. <br>
<br>
You can find them where Korath ships in human space are usually found(ember waste and eastern syndicate). <br>
The chance to encounter previous Korath ships or automata is like 50/50. <br>
<br>
<br>
Changelog:<br>
<br>
2023-10-17<br>
added plugin.txt<br>
<br>
2023-09-01<br>
added more fleet variants <br>
reworked readme <br>
changed icon.png<br>
