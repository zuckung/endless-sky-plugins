### unique.fix
<br>
<br>
Removes mass and outfit space from some uniques, puts others into unique category, or gives a png if there isn't one. See the readme for details.<br>
<br>
<br>
<ul>
<li> Removes mass and outfit space from the cloaking device. </li>
<li> Removes mass and outfit space from outskirts gauger and puts it in unique category. </li>
<li> Gives outfit '"Puny"' a portrait. </li>
<li> Puts outfit 'Mug' into unique category </li>
</ul>
<br>
<br>
Changelog:<br>
<br>
2024-03-15<br>
changed Puny png to ai generated<br>
<br>
2024-02-04<br>
removed mug image, because it got added in 0.10.5<br>
changed puny image to a poodle and added high res image <br>
<br>
2023-10-17<br>
added plugin.txt<br>
<br>
2023-8-31<br>
added 'Mug' to unique category and added a portrait<br>
changed puny portrait<br>
changed icon.png<br>
