### automata in human space <br>
(14 ship variants, 16 variants in 4 fleets)(made for 0.10.0) <br>
<br>
Brings jump drive equipped automata into human space after the wanderer campaign. <br>
You can find them where Korath ships in human space are usually found(ember waste and eastern syndicate). <br>
The chance to encounter previous Korath ships or automata is like 50/50. <br>