### additional command buttons <br>
(interface changed)(made for 0.10.1) <br>
<br>
Made for the mobile version and <br>
adds the following buttons: full stop / board ship / land on planet / fire afterburner / fleet: hold position / fleet: gather around me / view player info <br>
adjusts the message box to not overlap <br>
(inspired by theweirednut) <br>


Allthough most of these commands are now implemented in other parts the the original mobile ui, I personally prefer these buttons on the lower right corner. Additional there are some functions in this plugin that the original mobile ui can't do at the moment...<br>
- board button cycles through the possibilities<br>
- fleet commands can be used for single ships when selected<br>
