### too many asteroids <br>
(2654 system attributes changed, in 552 systems)(made for 0.10.1) <br>
<br>
Removes all non-mineable asteroids from all systems. Mineable asteroids and asteroid belts are untouched. <br>
<br>
2023/06/17 updated to 0.10.1<br>
2023/06/17 added a python script which generates the asteroids.txt(in case I don't update this mod, everyone can do it in no time.)<br>