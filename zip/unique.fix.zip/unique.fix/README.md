### unique fix <br>
(3 outfit attributes changed)(made for 0.10.0 continous) <br>
<br>
Removes mass and outfit space from the cloaking device. <br>
Removes mass and outfit space from outskirts gauger and puts it in unique category. <br>
Gives outfit '"Puny"' a portrait. <br>