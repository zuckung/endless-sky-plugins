### avgi.licenses<br>
<br>
Adds a mission on "Navigeo Yards" to get the 3 Avgi licenses.<br>
<br>
<br>
When you have completed the Avgi Intro (Avgi: Twilight Escape 3: done), land on "Navigeo Yards". You have a 20% chance kn getting the licenses mission, which leads you to the Gossamer system, where you have to mine some stuff and bring it back. Licenses have new images. You also get an unassigned Avgi unique.<br>
<br>
<br>
Changelog:<br>
<br>
2025-02-06<br>
initial release<br>
