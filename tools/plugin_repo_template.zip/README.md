check <a href="instructions.md">instructions.md</a> for details how this repo works and what to do to set it up correctly.
  


## Latest News:
<table><tr><td><img width="882" height="1"><br>2025-04-10 | initial template repository setup<br>
<img width="882" height="1"><br></td></tr></table>

## Plugin List:<br>
<table><tr valign="top"><td><img width="294" height="1"><br>
<a href="README.md#exampleplugin">example.plugin</a><br>
<img width="294" height="1"><br></td><td><img width="294" height="1"><br>
<img width="294" height="1"><br></td></tr></table>





---

### example.plugin

<img src="myplugins/example.plugin/icon.png" height="100">

[example.plugin.zip](https://github.com/zuckungtest/plugintemplate/releases/download/v1.0.2-example.plugin/example.plugin.zip) | 375.25 kb | 2025-04-12 | [view files](https://github.com/zuckungtest/plugintemplate/tree/main/myplugins/example.plugin/) | <a href="res/imagemd/example.plugin.md">view images</a> [9]<br>
<br>
>Adds a mission on "Navigeo Yards" to get the 3 Avgi licenses. See the README for details.

<details>
<summary>:blue_book: Plugin readme</summary>
<blockquote>### avgi.licenses<br>

<br>

Adds a mission on "Navigeo Yards" to get the 3 Avgi licenses.<br>

<br>

<br>

When you have completed the Avgi Intro (Avgi: Twilight Escape 3: done), land on "Navigeo Yards". You have a 20% chance kn getting the licenses mission, which leads you to the Gossamer system, where you have to mine some stuff and bring it back. Licenses have new images. You also get an unassigned Avgi unique.<br>

<br>

<br>

Changelog:<br>

<br>

2025-02-06<br>

initial release<br>

</blockquote>
</details>
<br>
screenshots(click to enlarge):<br>
<table>
	<tr>
		<td><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/master/screenshots/example.plugin01.jpg" width="200"></td>
	</tr>
</table>
<br>

<br>
