graphic files for the plugin: example.plugin<br>
<br>
<table>
	<tr valign="bottom">
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/icon.png"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/icon.png" width="150" height="150"></a><br>
		icon.png [150x150]</td>
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/images/outfit/avgi.licenses.1.png"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/images/outfit/avgi.licenses.1.png" width="180" height="180"></a><br>
		avgi.licenses.1.png [180x180]</td>
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/images/outfit/avgi.licenses.1@2x.png"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/images/outfit/avgi.licenses.1@2x.png" height="200"></a><br>
		avgi.licenses.1@2x.png [360x360]</td>
	</tr>
	<tr valign="bottom">
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/images/outfit/avgi.licenses.2.png"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/images/outfit/avgi.licenses.2.png" width="180" height="180"></a><br>
		avgi.licenses.2.png [180x180]</td>
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/images/outfit/avgi.licenses.2@2x.png"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/images/outfit/avgi.licenses.2@2x.png" height="200"></a><br>
		avgi.licenses.2@2x.png [360x360]</td>
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/images/outfit/avgi.licenses.3.png"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/images/outfit/avgi.licenses.3.png" width="180" height="180"></a><br>
		avgi.licenses.3.png [180x180]</td>
	</tr>
	<tr valign="bottom">
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/images/outfit/avgi.licenses.3@2x.png"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/images/outfit/avgi.licenses.3@2x.png" height="200"></a><br>
		avgi.licenses.3@2x.png [360x360]</td>
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/images/scene/avgi.licenses.general.jpg"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/images/scene/avgi.licenses.general.jpg" width="200"></a><br>
		avgi.licenses.general.jpg [560x340]</td>
		<td><a href="https://github.com/zuckungtest/plugintemplate/blob/main/myplugins/example.plugin/images/scene/avgi.licenses.general@2x.jpg"><img src="https://raw.githubusercontent.com/zuckungtest/plugintemplate/refs/heads/main/myplugins/example.plugin/images/scene/avgi.licenses.general@2x.jpg" width="200"></a><br>
		avgi.licenses.general@2x.jpg [1120x680]</td>
	</tr>
</table>
